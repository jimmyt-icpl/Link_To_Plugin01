"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "InvinsensePluginSetup", {
  enumerable: true,
  get: function () {
    return _types.InvinsensePluginSetup;
  }
});
Object.defineProperty(exports, "InvinsensePluginStart", {
  enumerable: true,
  get: function () {
    return _types.InvinsensePluginStart;
  }
});
exports.plugin = plugin;

var _plugin = require("./plugin");

var _types = require("./types");

// This exports static code and TypeScript types,
// as well as, OpenSearch Dashboards Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.InvinsensePlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIkludmluc2Vuc2VQbHVnaW4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQTs7QUFTQTs7QUFQQTtBQUNBO0FBRU8sU0FBU0EsTUFBVCxDQUFnQkMsa0JBQWhCLEVBQThEO0FBQ25FLFNBQU8sSUFBSUMsd0JBQUosQ0FBcUJELGtCQUFyQixDQUFQO0FBQ0QiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQgfSBmcm9tICcuLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgSW52aW5zZW5zZVBsdWdpbiB9IGZyb20gJy4vcGx1Z2luJztcblxuLy8gVGhpcyBleHBvcnRzIHN0YXRpYyBjb2RlIGFuZCBUeXBlU2NyaXB0IHR5cGVzLFxuLy8gYXMgd2VsbCBhcywgT3BlblNlYXJjaCBEYXNoYm9hcmRzIFBsYXRmb3JtIGBwbHVnaW4oKWAgaW5pdGlhbGl6ZXIuXG5cbmV4cG9ydCBmdW5jdGlvbiBwbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgcmV0dXJuIG5ldyBJbnZpbnNlbnNlUGx1Z2luKGluaXRpYWxpemVyQ29udGV4dCk7XG59XG5cbmV4cG9ydCB7IEludmluc2Vuc2VQbHVnaW5TZXR1cCwgSW52aW5zZW5zZVBsdWdpblN0YXJ0IH0gZnJvbSAnLi90eXBlcyc7XG4iXX0=